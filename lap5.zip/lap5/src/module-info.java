/**
 * 
 */
/**
 * 
 */
module lap5 {
}